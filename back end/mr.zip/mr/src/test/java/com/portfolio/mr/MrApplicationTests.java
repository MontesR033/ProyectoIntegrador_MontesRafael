package com.portfolio.mr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MrApplicationTests {

	@Test
	void contextLoads() {
	}

}
