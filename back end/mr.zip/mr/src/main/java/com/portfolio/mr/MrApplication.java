package com.portfolio.mr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MrApplication {

	public static void main(String[] args) {
		SpringApplication.run(MrApplication.class, args);
	}

}
